# Skills Registry

This registry defines the minimum skills used in the project startup and multiagent delivery workflow.

## Skill lifecycle

```text
Raw sources
→ source-index-builder
→ terminology-map-builder
→ requirement-slicing
→ issue-agent-readiness
→ orchestration-plan
→ implementation-plan
→ implementation
→ test-gap-review
→ security-review when needed
→ documentation-sync
→ pr-handoff
```

## Skills

| Skill | Use when | Output |
|---|---|---|
| source-index-builder | starting a new project or transforming an existing one | `docs/00-source-index.md` entries, reliability, open questions |
| terminology-map-builder | terms are unclear or business/code language diverges | canonical terminology table |
| requirement-slicing | turning brief/processes into GitHub Issues | epics, features, issue drafts, dependencies |
| issue-agent-readiness | before assigning work to Codex | readiness decision and missing info |
| orchestration-plan | task needs multiple roles, skills, or risk review | role plan, skill plan, write-owner, execution sequence |
| implementation-plan | before code changes | files likely to change, steps, tests, validation |
| test-gap-review | before PR readiness | missing tests, edge cases, validation gaps |
| security-review | auth, billing, DB, infra, CI, dependency, secret, data exposure risks | security findings and escalation decision |
| documentation-sync | behavior, terminology, API, or customer-facing docs changed | docs update plan and docs diff guidance |
| pr-handoff | before opening/updating PR | PR-ready handoff report |
| mcp-usage-guard | before using MCP tools | MCP usage plan, permission/risk decision |

## Explicit invocation examples

```text
Use $issue-agent-readiness for issue #12 and tell me whether it is agent-ready.
```

```text
Use $orchestration-plan and $mcp-usage-guard. Decide if GitHub MCP is needed for this task.
```

```text
Use $test-gap-review on the current diff. Do not modify files.
```

```text
Use $pr-handoff and prepare the PR body for the current branch.
```

## Design rule

Do not create a new skill until the workflow has repeated at least three times and the procedure is stable enough to document.
