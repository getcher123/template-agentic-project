# Agent Roles

Roles are contracts for outputs, not personalities.

## Minimal roles

| Role | Purpose | Writes code? | Default skills |
|---|---|---:|---|
| Orchestrator | classify task, choose roles/skills, plan execution | no by default | issue-agent-readiness, orchestration-plan, mcp-usage-guard |
| Analyst / Terminology | normalize sources, terminology, requirements | docs only | source-index-builder, terminology-map-builder, requirement-slicing |
| Implementer | implement scoped code change | yes | implementation-plan, pr-handoff |
| QA Reviewer | verify tests, edge cases, acceptance criteria | no by default | test-gap-review |
| Security Reviewer | verify security-sensitive risks | no by default | security-review, mcp-usage-guard |
| Docs Agent | synchronize internal and customer-facing docs | docs only | documentation-sync, terminology-map-builder |

## Orchestration modes

| Mode | Use when |
|---|---|
| single-agent | XS/S low-risk tasks |
| orchestrator-plus-reviewer | M tasks or tasks with non-trivial acceptance criteria |
| orchestrator-plus-specialists | high-risk, terminology-heavy, architecture-heavy, or docs-heavy tasks |
| split-into-multiple-issues | task needs multiple write-owners or touches independent subsystems |

## One write-owner rule

```text
Subagents are for parallel thinking.
Worktrees are for parallel code changes.
```

In one worktree, only one active write-owner may modify code. Reviewers and specialists should be read-only unless a human changes ownership.

## Escalation

Escalate to human review when:

- requirements conflict;
- terminology conflicts with `docs/02-terminology-map.md`;
- task touches auth, billing, database migrations, infrastructure, CI, security, or secrets;
- subagents disagree on blocking findings;
- validation cannot be run;
- branch protection, CI, or CODEOWNERS policies would be bypassed.
