# Codex New Project Agent Kit

Базовый набор skills и MCP-конфигурации для запуска нового проекта в модели:

```text
GitHub Issue
→ GitHub Project
→ Orchestrator
→ selected skills
→ one write-owner
→ git worktree
→ Codex implementation
→ PR
→ CI
→ human review
```

## Что входит

```text
.agents/skills/
├── source-index-builder/
├── terminology-map-builder/
├── requirement-slicing/
├── issue-agent-readiness/
├── orchestration-plan/
├── implementation-plan/
├── test-gap-review/
├── security-review/
├── documentation-sync/
├── pr-handoff/
└── mcp-usage-guard/

.codex/
└── config.toml

docs/
├── skills-registry.md
├── mcp-registry.md
└── agent-roles.md

AGENTS.skills-snippet.md
scripts/check-agent-kit.sh
```

## Установка в новый проект

Запусти из корня нового репозитория:

```bash
cp -R .agents .codex docs AGENTS.skills-snippet.md scripts .
chmod +x scripts/check-agent-kit.sh
./scripts/check-agent-kit.sh
```

После копирования добавь содержимое `AGENTS.skills-snippet.md` в корневой `AGENTS.md` проекта.

## Безопасный старт Codex

По умолчанию MCP-серверы в `.codex/config.toml` выключены через `enabled = false`. Это сделано специально: сначала проект должен быть доверенным, затем включаются только нужные MCP-серверы.

Для GitHub MCP перед запуском Codex установи токен из GitHub CLI:

```bash
export GITHUB_PERSONAL_ACCESS_TOKEN="$(gh auth token)"
```

Затем включи в `.codex/config.toml`:

```toml
enabled = true
```

для `[mcp_servers.github]`.

Для Context7 включи `enabled = true` в `[mcp_servers.context7]`.

## Рекомендуемый первый запуск

```bash
codex
```

Первый prompt:

```text
Работай как Orchestrator Agent для нового проекта.

Используй skills:
- source-index-builder
- terminology-map-builder
- requirement-slicing
- issue-agent-readiness
- orchestration-plan

Сначала не меняй код. Подготовь минимальный documentation baseline, список GitHub Issues для первого релиза и критерии agent-ready.
```

## Базовое правило

```text
Skills — это повторяемые процедуры.
MCP — это доступ к внешним системам.
Roles — это ответственность.
AGENTS.md — это постоянные правила.
GitHub — source of truth.
```
